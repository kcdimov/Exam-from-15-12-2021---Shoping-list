package com.shopping_list.demo.models.entities;

public enum CategoryEnumName {
//    an option between (Food, Drink, Household, Other)
    FOOD, DRINK, HOUSEHOLD, OTHER
}
